save variable
